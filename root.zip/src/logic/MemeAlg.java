package logic;

public class MemeAlg extends Thread {
	
	
	public MemeAlg(){
		
	}
	
	
	
	
	
	public void run()
	{
		/*
		Procedure Memetic Algorithm
		   Initialize: Generate an initial population; --> gera pessoal do hospital
		   while Stopping conditions are not satisfied do --> todas as horas da semana estejam atribuidas e com todas as demais restri�oes.
		       Evaluate all individuals in the population.  -->  avaliar os constraints de cada individuo ( enfermeira ) 
		       Evolve a new population using tabu search.  --> ?? 
		       Select the subset of individuals, , that should undergo the individual improvement procedure.  -->  selecciona uma subpopula�ao 
		       for each individual in  do
		           Perform individual learning using meme(s) with frequency or probability of , for a period of . --> aprende com as preferencias resultantes dos funcionarios ( acho ) 
		           Proceed with Lamarckian or Baldwinian learning. --> gera o novo horario tendo em conta o aprendido 
		       end for
		   end while
		   */

	}

}
